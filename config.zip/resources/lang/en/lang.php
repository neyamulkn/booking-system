<?php

 return [

 	'noBooking' => 'No booking on this day',
 ];