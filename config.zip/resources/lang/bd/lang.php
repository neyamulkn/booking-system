<?php

 return [

 	'noBooking' => 'এই দিনে কোনো বুকিং নাই ',
 ];