<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackagePurchase extends Model
{
    protected $guarded = [];
}
