<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
class HomeController extends Controller
{

    public function index(){
        return view('landing.index');
    }
    public function features(){
        return view('landing.features');
    }
    public function reviews(){
        return view('landing.reviews');
    } 

    public function privacy_policy(){
        return view('landing.privacy-policy');
    }
    public function pricing(){
        return view('landing.pricing');
    }
  

    public function terms_of_use(){
        return view('landing.terms-of-use');
    }

}
