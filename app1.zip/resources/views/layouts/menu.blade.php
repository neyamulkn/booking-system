<div class="mainbar">

  <div class="container">

    <button type="button" class="btn mainbar-toggle" data-toggle="collapse" data-target=".mainbar-collapse">
      <i class="fa fa-bars"></i>
    </button>

    <div class="mainbar-collapse collapse">

      <ul class="nav navbar-nav mainbar-nav">

        <li class="active">
          <a href="{{route('dashboard')}}">
            <i class="fa fa-dashboard"></i>
            Dashboard
          </a>
        </li>

        @if(Auth::user()->user_roleID == env('TEACHER'))
        <li class="dropdown ">
          <a href=" {{route('timeSlotCalender')}}" >
            <i class="fa fa-calendar"></i>
           Calender
          </a>
        </li>
        @else
        <li class="dropdown ">
          <a href="{{route('booking.index')}}" >
            <i class="fa fa-calendar"></i>
           Calender
          </a>
        </li>
        @endif

        <li class="dropdown ">
          <a href="{{route('bookingList')}}" >
            <i class="fa fa-clock-o"></i>
            Time Slots
          </a>
        </li>



        <li class="dropdown ">
          <a href="{{route('students')}}" >
            <i class="fa fa-users"></i>
            Cliends
          </a>
        </li>

        <li class="dropdown ">
          <a href="{{route('class_records')}}" >
            <i class="fa fa-history"></i>
            Session History
          </a>
        </li>

       <!--  <li class="dropdown ">
          <a href="{{route('package')}}" >
            <i class="fa fa-files-o"></i>
            Packages
          </a>
        </li> -->
        <li class="dropdown ">
          <a href="{{route('teaching.material')}}" >
            <i class="fa fa-files-o"></i>
            Resources 
          </a>
        </li>

        <li class="dropdown ">
          <a href="#contact" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown">
            <i class="fa fa-external-link"></i>
            Settings
            <span class="caret"></span>
          </a>

          <ul class="dropdown-menu" role="menu">
            <li>
              <a href="{{route('package.create')}}">
              <i class="fa fa-setting"></i> 
              &nbsp;&nbsp;Set Package
              </a>
             </li> 
            <li>
              <a href="#">
              <i class="fa fa-bell"></i> 
              &nbsp;&nbsp;Notifications
              </a>
            </li>     

          </ul>
        </li>

      </ul>

    </div> <!-- /.navbar-collapse -->   

  </div> <!-- /.container --> 

</div> <!-- /.mainbar -->
