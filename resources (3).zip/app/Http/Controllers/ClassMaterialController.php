<?php

namespace App\Http\Controllers;

use App\ClassMaterial;
use Illuminate\Http\Request;

class ClassMaterialController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ClassMaterial  $classMaterial
     * @return \Illuminate\Http\Response
     */
    public function show(ClassMaterial $classMaterial)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ClassMaterial  $classMaterial
     * @return \Illuminate\Http\Response
     */
    public function edit(ClassMaterial $classMaterial)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ClassMaterial  $classMaterial
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ClassMaterial $classMaterial)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ClassMaterial  $classMaterial
     * @return \Illuminate\Http\Response
     */
    public function destroy(ClassMaterial $classMaterial)
    {
        //
    }
}
