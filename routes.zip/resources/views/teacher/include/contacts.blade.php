<tr>
    <th>Wechat ID</th>
    <td>Larry23</td>
    <td>
      	<span class="label label-primary">visit account</span>
    </td>
</tr>